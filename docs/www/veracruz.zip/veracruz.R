## -----------------------------------------------------------------------------
#| include: false
library(np)
options(np.messages=FALSE)


## -----------------------------------------------------------------------------
#| label: fig-plot
#| fig-cap: "Plot"
par(cex=0.75)
data(faithful)
fhat <- npudens(~waiting+eruptions,data=faithful)
plot(fhat,xtrim=-0.1,view="fixed",main="")

